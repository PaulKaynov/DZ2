from django.contrib import admin

from polls.models import *
